<?php

return [
    'login' => 'تسجيل الدخول',
    'username' => 'اسم المستخدم',
    'rememberme' => 'تذكرني',
    'password' => 'كلمة المرور',
    'Forgot Your Password?' => 'هل نسيت كلمة المرور؟',
];