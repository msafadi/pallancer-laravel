<?php

return [
    'login' => 'Login',
    'username' => 'Username',
    'rememberme' => 'Remember Me',
    'password' => 'Password',
];