<p>Hello, {{ $name ?? '' }}</p>

<p>A new order has been created (Order #{{ $order_id ?? '' }}</p>

<p><a href="{{ $action ?? '' }}">Click to view the order</a></p>

<p>Thank you!</p>