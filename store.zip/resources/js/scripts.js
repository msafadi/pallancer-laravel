$('.elm').on('click', function(e) {
    alert();
});