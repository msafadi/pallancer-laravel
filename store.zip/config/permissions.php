<?php

return [
    'products.edit' => 'Can edit product',
    'products.delete' => 'Can delete product',
    'categories.edit' => 'Can edit category',
];