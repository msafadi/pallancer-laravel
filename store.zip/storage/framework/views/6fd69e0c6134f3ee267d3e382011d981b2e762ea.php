

<?php $__env->startSection('title', 'Products'); ?>

<?php $__env->startSection('content'); ?>

<?php echo $__env->make('admin._alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="d-flex">
  <h1 class="h3 mb-4 text-gray-800"><?php echo app('translator')->get('Products'); ?> <?php echo e($locale); ?></h1>
  <div class="ml-auto">
    <a href="<?php echo e(route('admin.products.create')); ?>" class="btn btn-sm btn-outline-success">Create new</a>
  </div>
  
</div>

<table class="table">
  <thead>
    <tr>
      <th>Image </th>
      <th>ID</th>
      <th>Name</th>
      <th>Description</th>
      <th>Category</th>
      <th>Price</th>
      <th>Created At</th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
      <td><img height="60" src="<?php echo e(asset('images/' . $product->image)); ?>"></td>
      <td><?php echo e($product->id); ?></td>
      <td><?php echo e($product->name); ?></td>
      <td><?php echo $product->description; ?></td>
      <td><?php echo e($product->category->name); ?></td>
      <td><?php echo e($product->price); ?></td>
      <td><?php echo e($product->created_at); ?></td>
      <td>
        <div class="d-flex">
          <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update', $product)): ?>
          <a class="btn btn-outline-primary btn-sm mr-1" href="<?php echo e(route('admin.products.edit', [$product->id])); ?>">Edit</a>
          <?php endif; ?>
          <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('products.delete', $product)): ?>
          <form method="post" action="<?php echo e(route('admin.products.destroy', [$product->id])); ?>">
            <?php echo method_field('delete'); ?>
            <?php echo csrf_field(); ?>
            <button type="submit" class="btn btn-outline-danger btn-sm delete">Delete</button>
          </form>
          <?php endif; ?>
        </div>
      </td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody>
</table>

<?php echo e($products->links()); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\PalLancer-Laravel\store\resources\views/admin/products/index.blade.php ENDPATH**/ ?>