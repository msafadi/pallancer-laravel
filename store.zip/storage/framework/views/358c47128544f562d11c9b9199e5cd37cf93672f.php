<?php echo e($slot); ?>

<?php /**PATH E:\PalLancer-Laravel\store\resources\views/vendor/mail/text/subcopy.blade.php ENDPATH**/ ?>