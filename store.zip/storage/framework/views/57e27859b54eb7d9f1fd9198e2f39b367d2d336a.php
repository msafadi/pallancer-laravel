

<?php $__env->startSection('content'); ?>

<div class="container">
<h1>Notifications</h1>

<table class="table">
    <thead>
        <tr>
            <th>Notification</th>
            <th>Time</th>
            <th>Read At</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $notifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notify): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr class="<?php echo e($notify->read()? '' : 'bg-info'); ?>">
            <td><a href="<?php echo e(route('notification.read', [$notify->id])); ?>"><?php echo e($notify->data['message']); ?></a></td>
            <td><?php echo e($notify->created_at->diffForHumans()); ?></td>
            <td><?php echo e($notify->read_at); ?></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\PalLancer-Laravel\store\resources\views/notifications.blade.php ENDPATH**/ ?>