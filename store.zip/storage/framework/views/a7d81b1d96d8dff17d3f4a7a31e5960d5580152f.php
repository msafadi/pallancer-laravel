<p>Hello, <?php echo e($name ?? ''); ?></p>

<p>A new order has been created (Order #<?php echo e($order_id ?? ''); ?></p>

<p><a href="<?php echo e($action ?? ''); ?>">Click to view the order</a></p>

<p>Thank you!</p><?php /**PATH E:\PalLancer-Laravel\store\resources\views/mails/order-created.blade.php ENDPATH**/ ?>