<?php if(session()->has('alert.success')): ?>
<div class="alert alert-success">
  <?php echo e(session('alert.success')); ?>

</div>
<?php endif; ?>
<?php if(session()->has('alert.error')): ?>
<div class="alert alert-danger">
  <?php echo e(session('alert.error')); ?>

</div>
<?php endif; ?><?php /**PATH E:\PalLancer-Laravel\store\resources\views/admin/_alert.blade.php ENDPATH**/ ?>