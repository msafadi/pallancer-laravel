

<?php $__env->startSection('title', 'Categories'); ?>

<?php $__env->startSection('sidebar'); ?>
##parent-placeholder-19bd1503d9bad449304cc6b4e977b74bac6cc771##
<ul>
  <li>Item 1</li>
  <li>Item 1</li>
  <li>Item 1</li>
</ul>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<?php echo $__env->make('admin._alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="d-flex">
  <h1 class="h3 mb-4 text-gray-800">Categories</h1>
  <div class="ml-auto">
    <a href="<?php echo e(route('admin.categories.create')); ?>" class="btn btn-sm btn-outline-success">Create new</a>
  </div>
  
</div>

<table class="table">
  <thead>
    <tr>
      <th>ID</th>
      <th>Name</th>
      <th>Parent</th>
      <th>Status</th>
      <th>Products #</th>
      <th>Created At</th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <?php $__currentLoopData = $entries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
      <td><?php echo e($category->id); ?></td>
      <td><?php echo e($category->name); ?></td>
      <td><?php echo e($category->parent->name); ?></td>
      <td><?php echo e($category->status); ?></td>
      <td><?php echo e($category->products_count); ?></td>
      <td><?php echo e($category->created_at); ?></td>
      <td>
        <div class="d-flex">
          <a class="btn btn-outline-primary btn-sm mr-1" href="<?php echo e(route('admin.categories.edit', [$category->id])); ?>">Edit</a>
          <form method="post" action="<?php echo e(route('admin.categories.delete', [$category->id])); ?>">
            <?php echo method_field('delete'); ?>
            <?php echo csrf_field(); ?>
            <button type="submit" class="btn btn-outline-danger btn-sm delete">Delete</button>
          </form>
        </div>
      </td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody>
</table>

<?php echo e($entries->links()); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\PalLancer-Laravel\store\resources\views/admin/categories/index.blade.php ENDPATH**/ ?>